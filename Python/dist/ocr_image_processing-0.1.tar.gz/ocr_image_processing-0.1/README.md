# OCR Image Processing

A Python script for processing images and extracting text using OCR (Optical Character Recognition) with the PaddleOCR library.

## Installation

Install dependencies using pip:

```bash
pip install .
